#include "main.h"

/* Global Input Buffer and Variables */
char input_string[100];
char prompt[50] = "minishell";
pid_t child_pid = 0;
Slist *head = NULL;

int main()
{
    /* Register signal handlers */
    signal(SIGINT, signal_handler);
    signal(SIGTSTP, signal_handler);
    signal(SIGCHLD, sigchld_handler);

    /* Start Shell */
    scan_input(prompt, input_string);

    return 0;
}