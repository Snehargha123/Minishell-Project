#include "main.h"

void scan_input(char *prompt, char *input_string)
{
    char *cmd;
    int ret;

    system("clear");

    while (1)
    {
        /* Display Prompt */
        printf("%s$ ", prompt);
        fflush(stdout);

        /* Read Command */
        if (fgets(input_string, 100, stdin) == NULL)
            continue;

        /* Remove Newline */
        input_string[strcspn(input_string, "\n")] = '\0';

        /* Ignore Empty Command */
        if (strlen(input_string) == 0)
            continue;

        /* Change Prompt */
        if (strncmp(input_string, "PS1=", 4) == 0)
        {
            strcpy(prompt, input_string + 4);
            continue;
        }

        /* Get Command */
        cmd = get_command(input_string);

        /* Check Command Type */
        ret = check_command_type(cmd);

        if (ret == 0)
        {
            char *external_commands[20];
            extract_external_commands(external_commands);
        }
        else if (ret == 1)
        {
            execute_internal_commands(input_string);
        }
        else
        {
            printf("%s : Command not found\n", cmd);
        }
    }
}

char *get_command(char *input_string)
{
    static char cmd[50];
    int i = 0;

    /* Copy characters until space or end of string (Fixed double && typo) */
    while (input_string[i] != ' ' &&
           input_string[i] != '\0' &&
           i < sizeof(cmd) - 1)
    {
        cmd[i] = input_string[i];
        i++;
    }

    cmd[i] = '\0';

    return cmd;
}

int check_command_type(char *command)
 {
     
            char *external_commands[]  = {
                    "bash",
                    "bunzip2",
                    "busybox",
                    "bzcat",
                    "bzcmp",
                    "bzdiff",
                    "bzegrep",
                    "bzexe",
                    "bzfgrep",
                    "bzgrep",
                    "bzip2",
                    "bzip2recover",
                    "bzless",
                    "bzmore",
                    "cat",
                    "chacl",
                    "chgrp",
                    "chmod",
                    "chown",
                    "chvt",
                    "cp",
                    "cpio",
                    "dash",
                    "date",
                    "dbus-cleanup-sockets",
                    "dbus-daemon",
                    "dbus-uuidgen",
                    "dd",
                    "df",
                    "dir",
                    "dmesg",
                    "dnsdomainname",
                    "domainname",
                    "dumpkeys",
                    "echo",
                    "ed",
                    "egrep",
                    "false",
                    "fgconsole",
                    "fgrep",
                    "findmnt",
                    "fuser",
                    "fusermount",
                    "getfacl",
                    "grep",
                    "gunzip",
                    "gzexe",
                    "gzip",
                    "hostname",
                    "ip",
                    "kbd_mode",
                    "kill",
                    "kmod",
                    "less",
                    "lessecho",
                    "lessfile",
                    "lesskey",
                    "lesspipe",
                    "ln",
                    "loadkeys",
                    "login",
                    "loginctl",
                    "lowntfs-3g",
                    "ls",
                    "lsblk",
                    "lsmod",
                    "mkdir",
                    "mknod",
                    "mktemp",
                    "more",
                    "mount",
                    "mountpoint",
                    "mt",
                    "mt-gnu",
                    "mv",
                    "nano",
                    "nc",
                    "nc.openbsd",
                    "netcat",
                    "netstat",
                    "nisdomainname",
                    "ntfs-3g",
                    "ntfs-3g.probe",
                    "ntfs-3g.secaudit",
                    "ntfs-3g.usermap",
                    "ntfscat",
                    "ntfsck",
                    "ntfscluster",
                    "ntfscmp",
                    "ntfsdump_logfile",
                    "ntfsfix",
                    "ntfsinfo",
                    "ntfsls",
                    "ntfsmftalloc",
                    "ntfsmove",
                    "ntfstruncate",
                    "ntfswipe",
                    "open",
                    "openvt",
                    "pidof",
                    "ping",
                    "ping6",
                    "plymouth",
                    "plymouth-upstart-bridge",
                    "ps",
                    "pwd",
                    "rbash",
                    "readlink",
                    "red",
                    "rm",
                    "rmdir",
                    "rnano",
                    "running-in-container",
                    "run-parts",
                    "sed",
                    "setfacl",
                    "setfont",
                    "setupcon",
                    "sh",
                    "sh.distrib",
                    "sleep",
                    "ss",
                    "static-sh",
                    "stty",
                    "su",
                    "sync",
                    "tailf",
                    "tar",
                    "tempfile",
                    "touch",
                    "true",
                    "udevadm",
                    "ulockmgr_server",
                    "umount",
                    "uname",
                    "uncompress",
                    "unicode_start",
                    "vdir",
                    "vmmouse_detect",
                    "which",
                    "whiptail",
                    "ypdomainname",
                    "zcat",
                    "zcmp",
                    "zdiff",
                    "zegrep",
                    "zfgrep",
                    "zforce",
                    "zgrep",
                    "zless",
                    "zmore",
                    "znew", 
                    NULL
                  };  
                 

char *builtins[] = {"echo", "printf", "read", "cd", "pwd", "pushd", "popd", "dirs", "let", "eval",
					"set", "unset", "export", "declare", "typeset", "readonly", "getopts", "source",
					"exit", "exec", "shopt", "caller", "true", "type", "hash", "bind", "help", NULL};
      
   int i;

    /* Check External Commands */
    for (i = 0; external_commands[i] != NULL; i++)
    {
        if (strcmp(command, external_commands[i]) == 0)
        {
            return 0; // External
        }
    }

    /* Check Internal Commands */
    for (i = 0; builtins[i] != NULL; i++)
    {
        if (strcmp(command, builtins[i]) == 0)
        {
            return 1; // Internal
        }
    }

    return 2; // Not found
}

void extract_external_commands(char **external_commands)
{
    int i = 0;
    int status;

    child_pid = fork();

    if (child_pid == 0)
    {
        /* Child Process */
        signal(SIGINT, SIG_DFL);
        signal(SIGTSTP, SIG_DFL);

        external_commands[i] = strtok(input_string, " ");

        while (external_commands[i] != NULL)
        {
            i++;
            external_commands[i] = strtok(NULL, " ");
        }

        execvp(external_commands[0], external_commands);
        perror("execvp");
        exit(EXIT_FAILURE);
    }
    else if (child_pid > 0)
    {
        /* Parent Process */
        waitpid(child_pid, &status, WUNTRACED);

        if (WIFSTOPPED(status))
        {
            insert_at_first(&head, child_pid, input_string, STOPPED);
            printf("\n[%d]+ Stopped\t%s\n", child_pid, input_string);
        }
        else
        {
            child_pid = 0;
        }
    }
    else
    {
        perror("fork");
    }
}

void execute_internal_commands(char *input_string)
{
    char cwd[100];
    char temp[100];
    char *first_word;
    char *second_word;
    char *value;

    strcpy(temp, input_string);
    first_word = strtok(temp, " ");

    if (first_word == NULL)
        return;

    if (strcmp(first_word, "cd") == 0)
    {
        second_word = strtok(NULL, " ");
        if (second_word == NULL)
        {
            printf("cd : Missing directory\n");
        }
        else
        {
            if (chdir(second_word) != 0)
                perror("chdir");
        }
    }
    else if (strcmp(first_word, "pwd") == 0)
    {
        if (getcwd(cwd, sizeof(cwd)) != NULL)
            printf("%s\n", cwd);
        else
            perror("getcwd");
    }
    else if (strcmp(first_word, "exit") == 0)
    {
        exit(0);
    }
    else if (strcmp(first_word, "echo") == 0)
    {
        second_word = strtok(NULL, " ");

        if (second_word == NULL)
        {
            printf("\n");
        }
        else if (strcmp(second_word, "$$") == 0)
        {
            printf("%d\n", getpid());
        }
        else if (second_word[0] == '$')
        {
            value = getenv(second_word + 1);
            if (value != NULL)
                printf("%s\n", value);
            else
                printf("\n");
        }
        else
        {
            printf("%s\n", second_word);
        }
    }
    else if (strcmp(first_word, "fg") == 0)
    {
        continue_foreground();
    }
    else if (strcmp(first_word, "bg") == 0)
    {
        continue_background();
    }
    else if (strcmp(first_word, "jobs") == 0)
    {
        display_jobs();
    }
    else
    {
        printf("Invalid Internal Command\n");
    }
}

void signal_handler(int signum)
{
    int status; // Declared missing status variable

    if (signum == SIGINT)
    {
        if (child_pid == 0)
        {
            printf("\n");
            printf("%s$ ", prompt);
            fflush(stdout);
        }
        else
        {
            kill(child_pid, SIGTERM);
            waitpid(child_pid, NULL, 0);
            child_pid = 0;
        }
    }
    else if (signum == SIGTSTP)
    {
        if (child_pid == 0)
        {
            printf("\n");
            printf("%s$ ", prompt);
            fflush(stdout);
        }
        else
        {
            kill(child_pid, SIGSTOP);
            waitpid(child_pid, &status, WUNTRACED);

            insert_at_first(&head, child_pid, input_string, status);
            child_pid = 0;
        }
    }
}

void continue_foreground(void)
{
    int status;

    if (head == NULL)
    {
        printf("No stopped process\n");
        return;
    }

    child_pid = head->pid;

    if (kill(child_pid, SIGCONT) == -1)
    {
        perror("kill");
        return;
    }

    waitpid(child_pid, &status, WUNTRACED);

    if (WIFEXITED(status) || WIFSIGNALED(status))
    {
        delete_first_node();
        child_pid = 0;
    }
    else if (WIFSTOPPED(status))
    {
        printf("\n[%d]+ Stopped\t%s\n", head->pid, head->command);
    }
}

void continue_background(void)
{
    if (head == NULL)
    {
        printf("No stopped process\n");
        return;
    }

    if (kill(head->pid, SIGCONT) == -1)
    {
        perror("kill");
        return;
    }

    printf("[%d] Running\t%s\n", head->pid, head->command);
    delete_first_node();
    child_pid = 0;
}

void display_jobs(void)
{
    Slist *temp = head;

    if (temp == NULL)
    {
        printf("No stopped jobs\n");
        return;
    }

    while (temp != NULL)
    {
        printf("[%d] Stopped\t%s\n", temp->pid, temp->command);
        temp = temp->link;
    }
}

void delete_first_node(void)
{
    if (head == NULL)
        return;

    Slist *temp = head;
    head = head->link;
    free(temp);
}

void sigchld_handler(int signum)
{
    int status;
    pid_t pid;
    (void)signum;

    /* WNOHANG allows non-blocking checking of terminated background processes */
    while ((pid = waitpid(-1, &status, WNOHANG)) > 0)
    {
        printf("\nBackground Process %d Completed\n", pid);
        printf("%s$ ", prompt);
        fflush(stdout);

        delete_node(pid);
    }
}

void delete_node(pid_t pid)
{
    Slist *temp = head;
    Slist *prev = NULL;

    if (head == NULL)
        return;

    if (head->pid == pid)
    {
        head = head->link;
        free(temp);
        return;
    }

    while (temp != NULL && temp->pid != pid)
    {
        prev = temp;
        temp = temp->link;
    }

    if (temp == NULL)
        return;

    prev->link = temp->link;
    free(temp);
}

int insert_at_first(Slist **head, pid_t pid, char *command, int status)
{
    Slist *new = malloc(sizeof(Slist));

    if (new == NULL)
    {
        return FAILURE;
    }

    new->pid = pid;
    strcpy(new->command, command);
    new->status = status;
    new->link = NULL;

    if (*head == NULL)
    {
        *head = new;
    }
    else
    {
        new->link = *head;
        *head = new;
    }

    return SUCCESS;
}