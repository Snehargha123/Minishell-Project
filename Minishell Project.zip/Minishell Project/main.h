#ifndef MAIN_H
#define MAIN_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdio_ext.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

#define BUILTIN     1
#define EXTERNAL    2
#define NO_COMMAND  3

#define SUCCESS 0
#define FAILURE -1

#define STOPPED 1
#define RUNNING 2

/* Linked List Structure for Job Control */
typedef struct node {
    pid_t pid;
    char command[100];
    int status;
    struct node *link;
} Slist;

void scan_input(char *prompt, char *input_string);
char *get_command(char *input_string);

int check_command_type(char *command);
void execute_internal_commands(char *input_string);
void signal_handler(int sig_num);
void extract_external_commands(char **external_commands);

void delete_node(pid_t pid);
void delete_first_node(void);
void display_jobs(void);
void continue_foreground(void);
void continue_background(void);

extern Slist *head;
extern char prompt[];
extern char input_string[];
extern pid_t child_pid;

void sigchld_handler(int signum);

int insert_at_first(Slist **head,
                    pid_t pid,
                    char *command,
                    int status);

#endif